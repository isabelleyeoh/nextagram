import React, { Component } from 'react';
import axios from 'axios';




class App extends React.Component {
  state = {

  }

 

componentDidMount = () => {

axios({
  method: 'get',
  url: 'https://insta.nextacademy.com/api/v1/users/',
  auth: {
    username: 'janedoe',
    password: 's00pers3cret'
  },
  data: {
    this.props.email
    this.props.password
  }, 
})
.then(result => {
  // If successful, we do stuffs with 'result'
  this.setState({
    users:result.data,
    isLoading: false
})
})
.catch(error => {
  // If unsuccessful, we notify users what went wrong
  console.log('ERROR: ', error)
  this.setState({
    hasErrors: true,
    isLoading: false
  })
});
}


render(){
  const {users, isLoading} = this.state
  return (
    <>
    
  </>
  )
 
}
}



export default App;
