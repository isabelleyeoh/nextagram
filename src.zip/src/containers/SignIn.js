import  React from "react";

export default class NavBar extends React.Component {
    state = {
    login: false, 
    checkedLogin: false
    }

    componentDidMount(){
        isLogin
    }

    render(){

    }
}