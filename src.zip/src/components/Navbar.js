import React from 'react';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  } from 'reactstrap';
import LoginModal from '../containers/Modal';
import { Link } from "react-router-dom"


export default class NavBar extends React.Component {

    state = {
      isOpen: false
    };

    // isOpen is a command to show modal
  
  toggle = () =>{
    this.setState({
      isOpen: !this.state.isOpen
    });
  }
  render() {
      const {isOpen} = this.state
    return (
      <div>
          {isOpen? <LoginModal toggle={this.toggle} isOpen={isOpen}/> : null}
          {/* passing toggle to LoginModal */}
        <Navbar color="light" light expand="md">
          <NavbarBrand href="/">Nextagram</NavbarBrand>
          <NavbarToggler onClick={this.toggle} />
          <Collapse isOpen={this.state.isOpen} navbar>
            <Nav className="ml-auto" navbar>
              <NavItem className='mr-3' >
              <Link to="/">Home</Link>
              </NavItem>
              <NavItem className='mr-3'>
              <Link to={`/users/1`}>My Profile</Link> 
              </NavItem>
              <NavItem className='mr-3'>
                <Link to ="/" onClick = {this.toggle}>Log In / Sign Up</Link>
                {/* this will take in toggle function to make isOpen true. In line 31, we will have log in modal running. */}
              </NavItem>
            </Nav>
          </Collapse>
        </Navbar>
      </div>
    );
  }
}
